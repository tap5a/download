Installation:
• Create “Tap5a” folder (if you don’t have it already) under: ~/Movies/Motion Templates/Titles/
• Move "Tap5a Multiline Text Background" folder to: ~/Movies/Motion Templates/Titles/Tap5a/

Requirements:
• Tap5a Multiline Text Background requires Final Cut Pro X 10.3

–––

TAP5A MULTILINE TEXT BACKGROUND

Multiline text with autosizing background for each line. Quick and useful for titles, lower 3rds and subtitles. Complete list of features below.

Features:
• Multiline text with autosizing background for each line
• Optimize performance by choosing max number of lines needed (3, 6, 12)
• Works with all text inspector parameters. Stylize your text freely
• Adjust background color, opacity and roundness
• Adjust background margins (horizontal, vertical)
• Offset background (horizontal, vertical)
• Put hole in background with Stencil Text option
• Add border to background
• Adjust border color, width and opacity

Known issues / limitations:
• Maximum number of lines is limited to 12 make performance better
• With some fonts background align to top of the font and not on the center. Use offset vertical adjustment to correct this.

For animation Multiline Text Background works well with my other free plugin Quick In-Out Animator: https://youtu.be/_iOl1qCt6xs

If you need single text block background with more customisation check also my free plugin Autosize Text Background: https://youtu.be/QbRyxxKwqvU

–––

You can find all my Free Final Cut Pro X Plugins here: http://bit.ly/2oGLAoH

If you find my plugins useful and want to support my hobby of making plugins for FCPX please feel free to donate any amount you think is equal to the value you received: https://paypal.me/tap5a

Subscribe my YouTube channel: http://bit.ly/tilaatap5a
    
Hope you enjoy this plugin!
Tapio ‘Tap5a’ Haaja

For feedback and comments: tapio.haaja@gmail.com