Installation:
• Create “Tap5a” folder (if you don’t have it already) under: ~/Movies/Motion Templates/Effects/
• Move "Tap5a Zoom Highlight" folder to: ~/Movies/Motion Templates/Effects/Tap5a/

Requirements:
• Tap5a Zoom Highlight requires Final Cut Pro X 10.3

–––

TAP5A ZOOM HIGHLIGHT

Highlight part of your picture by zooming it closer. Free Tap5a Zoom Highlight effect for Final Cut Pro X features lots of options and easy setup mode. Complete list of features and download link below.

Features:
• Easy setup mode
• Choose between rectangle/circle highlight area
• Adjust size and roundness of highlight area
• Rotate highlight area and/or zoomed highlight area
• Adjust zoom amount
• Adjust zoom time between 0,5s - 2s
• Sharpen highlight area
• Add border to highlight area
• Add drop shadow to highlight area
• Blur background
• Desature background
• Overlay color over background

–––

You can find all my Free Final Cut Pro X Plugins here: http://bit.ly/2oGLAoH

If you find my plugins useful and want to support my hobby of making plugins for FCPX please feel free to donate any amount you think is equal to the value you received: https://paypal.me/tap5a

Subscribe my YouTube channel: http://bit.ly/tilaatap5a
    
Hope you enjoy this plugin!
Tapio ‘Tap5a’ Haaja

For feedback and comments: tapio.haaja@gmail.com 