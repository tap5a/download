Installation:
• Create “Tap5a” folder (if you don’t have it already) under: ~/Movies/Motion Templates/Effects/
• Move "Tap5a Multiline Text Boxer" folder to: ~/Movies/Motion Templates/Titles/Tap5a/

Requirements:
• Tap5a Multiline Text Boxes requires Final Cut Pro X 10.7

–––

TAP5A MULTILINE TEXT BOXES

Multiline text with autosizing boxes for each line. Quick and useful for TikTok style texts, titles, lower 3rds and subtitles. Complete list of features below.

Features:
• Multiline text with autosizing boxes for each line
• Works with all text inspector parameters. Stylize your text freely
• Choose between multiline text boxes or single text box
• Adjust background color, opacity and roundness
• Adjust background margins
• Offset background (horizontal, vertical)
• Put hole to boxes with Stencil Text option
• Add border to background
• Adjust border color, width and opacity
• Offset border (relative, horizontal, vertical)
• Put border behing background
• Add drop shadow and adjust drop shadow color, opacity, blur, distance and angle
• Fine tune with transform options of scale and rotation

Known issues / limitations:
• Maximum number of lines is limited to 10 to keep performance good.

For animation Multiline Text Boxes works well with my other free plugins such as Quick In-Out Animator & Quick In-Out Bouncer & Quick In-Out Revealer. You can find all my Free Final Cut Pro X Plugins here: http://bit.ly/2oGLAoH

–––

If you find my plugins useful and want to support my hobby of making plugins for FCPX please feel free to donate any amount you think is equal to the value you received: https://paypal.me/tap5a

Subscribe my YouTube channel: http://bit.ly/tilaatap5a
    
Hope you enjoy this plugin!
Tapio ‘Tap5a’ Haaja

For feedback and comments: tapio.haaja@gmail.com