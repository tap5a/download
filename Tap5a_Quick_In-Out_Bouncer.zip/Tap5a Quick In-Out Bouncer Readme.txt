Installation:
• Create “Tap5a” folder (if you don’t have it already) under: ~/Movies/Motion Templates/Effects/
• Move "Tap5a Quick In-Out Bouncer" folder to: ~/Movies/Motion Templates/Effects/Tap5a/

Requirements:
• Tap5a Quick In-Out Bouncer requires Final Cut Pro X 10.4.8

–––

TAP5A QUICK IN-OUT BOUNCER

Quickly bounce elements in-out without messing with keyframes, transitions and secondary storylines. Complete list of features and download link below.

Features:
• Super quick and easy to use
• Choose type of bounce as overshoot or bounce back
• Choose from 14 different in-out bounces
— Fly From/To Left
— Fly From/To Right
— Fly From/To Top
— Fly From/To Bottom
— Float From/To Left
— Float From/To Right
— Float From/To Top
— Float From/To Bottom
— Zoom From/To In
— Zoom From/To Out
— Spin In/Out CW
— Spin In/Out CCW
— Spin In/Out Zoom CW
— Spin In/Out Zoom CCW
• Adjust bounce time (0,5s - 1,5s)
• Adjust movement size
• Adjust bounciness
• Adjust motion blur amount
• Move center point

Good to know:
• For elements smaller than your project resolution you might need to first compound clip your element
• Element must be at least 2,5 seconds long for both in and out bounces to work correctly in every situation
• To make Quick In-Out Bouncer work for very short and quick elements duplicate it and disable Build Out in first one and Build In in second one


–––

You can find all my Free Final Cut Pro X Plugins here: http://bit.ly/2oGLAoH

If you find my plugins useful and want to support my hobby of making plugins for FCPX please feel free to donate any amount you think is equal to the value you received: https://paypal.me/tap5a

Subscribe my YouTube channel: http://bit.ly/tilaatap5a
    
Hope you enjoy this plugin!
Tapio ‘Tap5a’ Haaja

For feedback and comments: tapio.haaja@gmail.com 