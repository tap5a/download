Installation:
• Create “Tap5a” folder (if you don’t have it already) under: ~/Movies/Motion Templates/Titles/
• Move "Tap5a Autosize Text Background" folder to: ~/Movies/Motion Templates/Titles/Tap5a/

Requirements:
• Tap5a Autosize Text Background requires Final Cut Pro X 10.3

–––

TAP5A AUTOSIZE TEXT BACKGROUND

Text with background that autosizes itself based on text boundaries. Quick and useful for subtitles, titles and lower 3rds. Complete list of features and download link below.

Features:
• Text background that autosizes itself based on text boundaries
• Works with all text inspector parameters. Stylize your text freely
• Adjust background color, opacity and roundness
• Put hole in background with Stencil Text option
• Add border to background
• Adjust border color, width and opacity
• Choose which sides have border (all, top, bottom, right, left, top & bottom, right & left)
• Adjust margins (all, top, bottom, right, left)

For animation Autosize Text Background works well with my other free plugin called Quick In-Out Animator: https://youtu.be/_iOl1qCt6xs

–––

You can find all my Free Final Cut Pro X Plugins here: http://bit.ly/2oGLAoH

If you find my plugins useful and want to support my hobby of making plugins for FCPX please feel free to donate any amount you think is equal to the value you received: https://paypal.me/tap5a

Subscribe my YouTube channel: http://bit.ly/tilaatap5a
    
Hope you enjoy this plugin!
Tapio ‘Tap5a’ Haaja

For feedback and comments: tapio.haaja@gmail.com 