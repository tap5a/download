Installation:
• Create “Tap5a” folder (if you don’t have it already) under: ~/Movies/Motion Templates/Titles/
• Move "Tap5a Simple Text Revealer" folder to: ~/Movies/Motion Templates/Titles/Tap5a/

Requirements:
• Tap5a Simple Text Revealer requires Final Cut Pro X 10.3

–––

TAP5A SIMPLE TEXT REVEALER

16 simple, clean and modern ways to reveal/conceal your text quickly and easily.

Features:
• Super quick and easy to use
• Choose from 16 different revealers/concealers
— Fade In/Out
— Wipe From/To Left
— Wipe From/To Right
— Wipe From/To Top
— Wipe From/To Bottom
— Behind From/To Left
— Behind From/To Right
— Behind From/To Top
— Behind From/To Bottom
— Split From/To Horizontal
— Split From/To Vertical
— Cursor From/To Left
— Cursor From/To Right
— Modern From/To Left
— Modern From/To Right
— Modern From/To Top
— Modern From/To Bottom
• Adjust reveal/conceal time (0,1 - 1sec)
• Adjust motion blur amount

Potential issues:
• Title must be at least 2 seconds long for both reveal and conceal to work correctly in every situation

For even more possibilities combine Simple Text Revealer with my other free plugin Quick In-Out Animator: https://youtu.be/_iOl1qCt6xs

–––

You can find all my Free Final Cut Pro X Plugins here: http://bit.ly/2oGLAoH

If you find my plugins useful and want to support my hobby of making plugins for FCPX please feel free to donate any amount you think is equal to the value you received: https://paypal.me/tap5a

Subscribe my YouTube channel: http://bit.ly/tilaatap5a
    
Hope you enjoy this plugin!
Tapio ‘Tap5a’ Haaja

For feedback and comments: tapio.haaja@gmail.com 