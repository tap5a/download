Installation:
• Create “Tap5a” folder (if you don’t have it already) under: ~/Movies/Motion Templates/Titles/
• Move "Tap5a Multiline Text Backgr.2" folder to: ~/Movies/Motion Templates/Titles/Tap5a/

Requirements:
• Tap5a Multiline Text Background 2 requires Final Cut Pro X 10.7

–––

TAP5A MULTILINE TEXT BACKGROUND 2

Tap5a Multiline Background 2 is much faster, stabler and offers more features than the original Tap5a Multiline Text Background. It’s quick and useful for TikTok style texts, titles, lower 3rds and subtitles. Complete list of features below.

Features:
• Multiline text with autosizing background for each line
• Works with all text inspector parameters. Stylise your text freely
• Choose between multiline text background or single background
• Enable/disable background
• Adjust background color, opacity and roundness
• Adjust background margins
• Adjust background offset (horizontal, vertical)
• Put hole to background with Stencil Text option
• Enable/disable border
• Adjust border color, width and opacity
• Adjust border offset (relative, horizontal, vertical)
• Put border behind background
• Enable/disable drop shadow
• Adjust drop shadow colour, opacity, blur, distance and angle
• Fine tune size and rotation with scale and rotation transformations

Known issues / limitations:
• Maximum number of lines is limited to 10 to keep performance good

For animation Multiline Text Background 2 works well with my other free plugins such as Quick In-Out Animator & Quick In-Out Bouncer & Quick In-Out Revealer. You can find all my Free Final Cut Pro X Plugins here: http://bit.ly/2oGLAoH

–––

If you find my plugins useful and want to support my hobby of making plugins for FCPX please feel free to donate any amount you think is equal to the value you received: https://paypal.me/tap5a

Subscribe my YouTube channel: http://bit.ly/tilaatap5a
    
Hope you enjoy this plugin!
Tapio ‘Tap5a’ Haaja

For feedback and comments: tapio.haaja@gmail.com