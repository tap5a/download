Installation:
• Create “Tap5a” folder (if you don’t have it already) under: ~/Movies/Motion Templates/Effects/
• Move "Tap5a Quick In-Out Revealer" folder to: ~/Movies/Motion Templates/Effects/Tap5a/

Requirements:
• Tap5a Quick In-Out Revealer requires Final Cut Pro X 10.3

–––

TAP5A QUICK IN-OUT REVEALER

Quickly reveal/conceal selected area without messing with keyframes, masks or transitions. Great for revealing texts, logos etc. Complete list of features below.

Features:
• Super quick and easy to use
• Select area you want to reveal (position, width, height)
• Choose from 18 different revealers/concealers
— Fade In/Out
— Zoom In/Out
— Wipe From/To Left
— Wipe From/To Right
— Wipe From/To Top
— Wipe From/To Bottom
— Behind From/To Left
— Behind From/To Right
— Behind From/To Top
— Behind From/To Bottom
— Split From/To Horizontal
— Split From/To Vertical
— Flip In/Out Horizontal
— Flip In/Out Vertical
— Flip From/To Left
— Flip From/To Left
— Flip From/To Right
— Flip From/To Top
— Flip From/To Bottom
• Adjust Animation Time (0,1s - 1s)
• Adjust Motion Blur amount

Known issues / limitations:
• Element must be at least 2 seconds long for both revealer and concealer to work correctly in every situation
• For elements smaller than your project resolution you might need to first compound clip your element

For even more animation possibilities use Quick In-Out Revealer together with my other free plugin Quick In-Out Animator: https://youtu.be/_iOl1qCt6xs

–––

You can find all my Free Final Cut Pro X Plugins here: http://bit.ly/2oGLAoH

If you find my plugins useful and want to support my hobby of making plugins for FCPX please feel free to donate any amount you think is equal to the value you received: https://paypal.me/tap5a

Subscribe my YouTube channel: http://bit.ly/tilaatap5a
    
Hope you enjoy this plugin!
Tapio ‘Tap5a’ Haaja

For feedback and comments: tapio.haaja@gmail.com